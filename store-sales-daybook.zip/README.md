# 店销日集（store-sales-daybook）

门店销售日报收集与统计系统：店员用手机按引导逐条录入当日销售，总部/区域管理员在后台看完成率、明细与操作日志。

- 运行时：Node.js 22 + Express 4，数据库为 **Node 内置 `node:sqlite`**（无原生模块编译，镜像稳定）
- 前端：原生 HTML/CSS/JS，无构建步骤，移动端优先
- 部署：单容器 Docker / docker-compose，数据全部落在 `/app/data` 卷

---

## 1. 功能一览

| 角色 | 能力 |
| --- | --- |
| 店员 `clerk` | 仅看本门店今日/昨日两次（上午、下午）是否已提交；引导式逐条填报（只显示商品**别名**，不暴露真实品名与条码）；昨日数据在次日 12:00 前可补交 |
| 区域管理员 `region_admin` | 与总部管理员同样的报表视角，但数据仅限被授权管辖的门店（建号时直接勾选门店，不经「区域」这层）；可查看所辖门店的免登录链接与二维码，**不可**修改门店、不可看操作日志 |
| 总部管理员 `admin` | 全部门店、商品、账号的增删改；概览按区域管理员分组的品类柱形图（可展开门店）；门店完成率卡片 → 提交详情；区间明细与 CSV 导出；操作日志（IP 归属地 / 设备指纹，IP 库在线更新） |

核心规则：

- **每日两个时段**：`am` 上午、`pm` 下午。当天两个时段在 24 点前都可填报；**昨日**仅在当日 12:00 前可补交，逾期锁定。
- **数据隔离**：店员会话只返回「已提交 / 未提交」与商品别名，不回传历史数量与真实品名；区域管理员通过 `user_stores` 直接限定可见门店范围。
- **商品关联**：门店未选择关联商品时，默认关联**全部启用**商品；选择后只处理关联商品。商品「禁用」后不参与展示与统计。
- **商品档案维度**：每个商品带「品类」（输入框，可选已有品类也可直接输入新品类，留空归入「未分类」）与「属性」（本品 / 竞品，默认本品）。批量导入按「品名、别名、条码、品类、属性」解析。
- **概览口径**：概览按**区域管理员**分组展示柱形图——每组是该管理员所辖门店当天上午 + 下午销量按品类汇总，同一品类内本品（高亮）与竞品并排对比；当天未提交的商品按 0 计入；每组最左侧为当天提交完成率，点击展开门店维度明细。未被任何启用区域管理员管辖的门店，单独汇总为一条「未绑定」数据条。
- **免登录门店链接**：新建门店自动生成 token；门店列表可复制链接、显示二维码（链接携带 `门店编码` 与 `门店名称` 便于区分）、开关可用性、重置 token。链接可用性开关默认打开。总部管理员可重置，区域管理员只能查看所辖门店的链接。
- **操作日志**：账号创建/修改密码/删除图片/免登录登录/导出/IP 库更新等全记录，含 IP、ip2region 归属地、设备指纹、网络类型。
- **设备指纹稳定性**：指纹基于归一化 UA（剥离微信 WebView 的 `NetType/WIFI`、`NetType/4G` 等网络标记与版本号）+ 屏幕/时区/语言/平台等固有特征，因此**换 IP、切 WiFi/4G/5G 时指纹不变**。

## 2. 快速部署（Docker）

```bash
git clone <repo> store-sales-daybook && cd store-sales-daybook

cp .env.example .env          # 按需修改端口、对外地址、初始管理员密码
docker compose up -d --build

docker compose logs -f daybook   # 首次启动会打印初始管理员账号与密码
```

打开 `http://<服务器IP>:3000`，用日志中的总部管理员账号登录（若未设置 `INIT_ADMIN_PASSWORD`，密码随机生成，同时写入 `data/initial-admin-password.txt`，登录后请立即修改）。

### 环境变量

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `APP_PORT` | `3000` | 宿主机映射端口（仅 compose 使用） |
| `PUBLIC_BASE_URL` | 空 | 对外访问根地址，如 `https://sales.example.com`。**生成免登录链接与二维码时使用**；留空则按请求 Host 推导，反向代理场景建议显式设置 |
| `APP_TZ_OFFSET` | `8` | 业务时区相对 UTC 的小时偏移（北京时间） |
| `SESSION_DAYS` | `14` | 登录会话有效天数 |
| `COOKIE_SECURE` | `0` | HTTPS 部署设为 `1`，会话 Cookie 加 `Secure` |
| `INIT_ADMIN_USERNAME` / `INIT_ADMIN_PASSWORD` | `admin` / 空 | 内置超级管理员账号。**配置了 `INIT_ADMIN_PASSWORD` 时密码以环境变量为唯一来源**：每次启动校验并同步，系统内（改密页 / 后台重置）不允许修改；留空则首次启动随机生成并写入 `data/initial-admin-password.txt`，此时可自行改密 |
| `DATA_DIR` | `./data` | 宿主机数据目录，映射到容器 `/app/data` |
| `DB_PATH` | 空 | 覆盖 SQLite 文件路径（默认 `$DATA_DIR/app.db`） |
| `IPDB_IMAGE_FILE` | 空 | 覆盖镜像内置 IP 库路径（默认 `/app/vendor/ip2region_v4.xdb`） |

### 数据与备份

所有持久化数据都在数据卷内：

```
data/
├── app.db                        # SQLite（WAL 模式）
├── app.db-wal / app.db-shm
├── uploads/                      # 销售凭证图片
├── ipdb/                         # 后台「更新 IP 库」下载的版本（优先于镜像内置）
└── initial-admin-password.txt    # 仅随机生成初始密码时存在
```

备份只需停容器后拷贝整个 `data/` 目录（或 `sqlite3 data/app.db ".backup ..."` 热备）：

```bash
docker compose stop daybook
tar czf backup-$(date +%F).tar.gz data/
docker compose start daybook
```

### IP 归属地库

镜像构建时由 `scripts/fetch-ipdb.js` 从 ip2region 上游下载 v4 xdb 到 `/app/vendor`；**网络不可用时自动回退** npm 包内置的 xdb，保证离线也能构建。运行期可在「操作日志 → IP 库」：

- **校验更新**：只查上游版本，不下载；
- **更新 IP 库**：下载最新 xdb，校验可解析后热替换，无需重启。

本地不使用 Docker 时：`npm run fetch:ipdb` 会生成同样的 `vendor/`。

### 反向代理（可选）

```nginx
server {
  listen 443 ssl;
  server_name sales.example.com;

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    client_max_body_size 6m;   # 凭证图片上限 5MB
  }
}
```

配合 `.env`：`PUBLIC_BASE_URL=https://sales.example.com`、`COOKIE_SECURE=1`。

## 3. 本地开发

```bash
cp .env.example .env   # 可选；本地启动同样会读取根目录 .env（不覆盖已有环境变量）
npm install
npm run dev      # node --experimental-sqlite --watch server.js
npm test         # 端到端冒烟（真实启动 HTTP 服务跑完整业务链路）
```

> Node 22.x 需要 `--experimental-sqlite`（脚本已内置）；Node 24+ 可省略。

### 忘记管理员密码

内置管理员配置了 `INIT_ADMIN_PASSWORD` 时，直接改环境变量并重启即可（以环境变量为唯一来源）。
其他情况（未配置环境变量、或账号是系统内创建的）用命令行重置：

```bash
node --experimental-sqlite scripts/reset-password.js --user admin          # 随机生成新密码
node --experimental-sqlite scripts/reset-password.js --user admin --password 新密码 --unlock
```

重置会清除该账号的全部会话并写入操作日志；容器内执行：
`docker compose exec daybook node --experimental-sqlite scripts/reset-password.js --user admin`。

## 4. 目录结构

```
server.js                 # 应用装配、页面路由、/s/:token 免登录入口
src/
├── db.js                 # schema、迁移、初始化管理员
├── sqlite.js             # node:sqlite 薄封装（事务/命名参数）
├── auth.js               # 会话、RBAC、可见门店范围
├── security.js           # 密码哈希、登录限流
├── net.js                # 客户端 IP、UA 归一化、设备指纹
├── audit.js              # 操作日志写入与查询
├── ipdb.js               # ip2region 解析、版本校验与热更新
├── report.js             # 概览柱形图（管理员×品类）/ 单日总览 / 门店完成率 / 明细
└── routes/               # auth stores catalog users sales reports logs
public/                   # login / clerk（店员）/ admin（后台）/ password
scripts/fetch-ipdb.js     # 镜像构建期预置 IP 库
scripts/docker-entrypoint.sh  # 容器入口：修正数据卷属主后降权到 node 启动
test/smoke.test.js        # 端到端冒烟
```

## 5. 接口速览

| 分组 | 主要接口 |
| --- | --- |
| 认证 | `POST /api/auth/login`、`POST /api/auth/logout`、`GET /api/auth/me`、`POST /api/auth/password` |
| 门店 | `GET/POST /api/stores`、`POST /api/stores/batch`（批量粘贴编码+名称）、`GET/PUT /api/stores/:id`、`PUT /api/stores/:id/products`、`PATCH /api/stores/:id/auto-login`、`POST /api/stores/:id/rotate-token`、`GET /api/stores/:id/qrcode` |
| 商品 | `GET/POST /api/products`、`PUT/DELETE /api/products/:id`、`POST /api/products/batch` |
| 账号 | `GET/POST /api/users`、`PUT/DELETE /api/users/:id`、`GET /api/users/options` |
| 填报 | `GET /api/sales/home`、`GET /api/sales/session`、`PUT /api/sales/entry`、`POST /api/sales/fill-zero`、`POST /api/sales/submit`、凭证图片 `GET/POST/DELETE /api/sales/images` |
| 报表 | `GET /api/reports/manager-day`（概览柱形图：按区域管理员分组的品类×本品/竞品销量 + 门店明细 + 完成率）、`/recent`（7 日 日期-门店编码-完成率）、`/day`（总数+各门店）、`/stores`（区间门店完成率）、`/detail`（按日期折叠）、`/export`（CSV） |
| 日志 | `GET /api/logs`、`GET /api/logs/ipdb`、`POST /api/logs/ipdb/check`、`POST /api/logs/ipdb/update` |
| 免登录 | `GET /s/:token?c=<门店编码>&n=<门店名称>` |

页面：`/login`、`/clerk`（店员移动端）、`/admin`（后台）、`/password`、`/healthz`（健康检查）。
